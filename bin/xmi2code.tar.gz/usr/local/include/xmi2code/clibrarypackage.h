#ifndef CLIBRARYPACKAGE_H
#define CLIBRARYPACKAGE_H

#include <list>

class MDependency;

class CLibraryPackage : public CPackageBase
{
public:
    CLibraryPackage();
    CLibraryPackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {type = eLibraryPackage;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
private:
    std::ofstream makefile;
};

#endif // CLIBRARYPACKAGE_H
