#ifndef CPHPPACKAGE_H
#define CPHPPACKAGE_H

#include <string>
#include "cpackagebase.h"

class CPHPPackage : public CPackageBase
{
public:
    CPHPPackage();
    CPHPPackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {};
    virtual ~CPHPPackage();
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
};

#endif // CPHPACKAGE_H
