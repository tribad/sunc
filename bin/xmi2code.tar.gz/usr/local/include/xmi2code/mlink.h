#ifndef MLINK_H
#define MLINK_H

#include "massociation.h"

class MLink : public MAssociation
{
public:
    MLink();
    MLink(const std::string&aId, MElement *aParent=0) : MAssociation(aId, aParent) {type=eLink;};
    static MLink* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MLINK_H
