#ifndef CCCLASS_H
#define CCCLASS_H

#include "melement.h"
#include "cclassbase.h"

class CCClass : public CClassBase
{
public:
    CCClass();
    CCClass(const std::string &aId, MElement *e) : CClassBase(aId, e) {type = eCClass;};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);

};

#endif // CCCLASS_H
