#ifndef CMODEL_H
#define CMODEL_H

#include <iostream>
#include "mmodel.h"

class CModel : public MModel
{
public:
    CModel();
    //
    //
    virtual void Prepare(void);
    virtual void Dump(void);
    //
    void Merge(void);
    void Merge(const std::string& gfile, const std::string& ofile, const std::string& comment);
public:
    std::list<std::string> pathstack;
    std::list< std::pair <std::string, std::string > > generatedfiles;
private:
    std::string Directory;

};

#endif // CMODEL_H
