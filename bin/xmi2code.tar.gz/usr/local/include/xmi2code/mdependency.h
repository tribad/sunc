#ifndef MDEPENDENCY_H
#define MDEPENDENCY_H

#include "melement.h"

class MDependency : public MElement
{
public:
    MDependency();
    MDependency(const std::string&aId, MElement *aParent=0) : MElement(aId, aParent) {type=eDependency;};
    static MDependency* construct(const std::string&aId, MStereotype* aStereotype, MElement *aParent=0);
public:
    static std::map<std::string, MDependency*> Instances;
    std::string src_ref;
    MElement* src;
    std::string target_ref;
    MElement* target;
};

#endif // MDEPENDENCY_H
