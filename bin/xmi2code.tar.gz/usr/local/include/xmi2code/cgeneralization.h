#ifndef CGENERALIZATION_H
#define CGENERALIZATION_H

#include "mgeneralization.h"

class CGeneralization : public MGeneralization
{
public:
    CGeneralization();
    CGeneralization(const std::string &aId, MElement *e) : MGeneralization(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CGENERALIZATION_H
