#ifndef MUSECASE_H
#define MUSECASE_H

#include <vector>
#include <map>
#include "melement.h"
#include "mattribute.h"

class MUseCase : public MElement
{
public:
    MUseCase();
    MUseCase(const std::string&aId, MElement *aParent=0);
    static MUseCase* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MUseCase*> Instances;
public:
    std::vector<MAttribute*>      Attribute;
};

#endif // MUSECASE_H
