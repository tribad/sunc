#ifndef CSTRUCT_H
#define CSTRUCT_H


class CStruct : public CClassBase
{
public:
    CStruct();
    CStruct(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = eStruct;};
    virtual void SetFromTags(const std::string& name, const std::string&value);
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
private:
    std::string lower_name;
    std::string upper_name;
};

#endif // CSTRUCT_H
