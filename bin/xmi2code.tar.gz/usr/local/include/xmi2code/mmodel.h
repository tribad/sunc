#ifndef MMODEL_H
#define MMODEL_H

#include <list>
#include <map>
#include <utility>
#include <string>

#include "mstereotype.h"
#include "mclass.h"
#include "mpackage.h"
#include "massociation.h"
#include "massociationend.h"
#include "mattribute.h"

class MModel
{
public:
    MModel();
    static MModel* construct();
    void Add(MStereotype *s);
    void Add(MPackage *p);
    void Add(MAssociation *a);
    void Add(MAssociationEnd *e);
    void AddTag(const std::string &name, const std::string& value);
    MStereotype* StereotypeById(std::string id);
    MStereotype* StereotypeByName(std::string name);
    void Complete(void);
protected:
    std::list< MStereotype*>           Stereotype;
    std::list< MPackage*>              Packages;
    std::list< MAssociation*>          Associations;
    std::list< MAssociationEnd*>       AssociationEnds;
    std::map<std::string, std::string> TaggedValues;

};

#endif // MMODEL_H
