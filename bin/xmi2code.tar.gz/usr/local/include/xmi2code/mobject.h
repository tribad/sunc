#ifndef MOBJECT_H
#define MOBJECT_H

#include "melement.h"
#include "mlink.h"
#include "mattribute.h"

class MObject : public MElement
{
public:
    MObject();
    MObject(const std::string&aId, MElement *aParent=0);
    static MObject* construct(const std::string&aId, MStereotype* aStereotype, MElement *aParent=0);
    void Add(MAttribute* a) {Slots.push_back(a);owned.push_back(a);};
    void Add(MLink* l) {Links.push_back(l);owned.push_back(l);};
public:
    static std::map<std::string, MObject*> Instances;
    std::vector<MLink*>      Links;
    std::vector<MAttribute*> Slots;
};

#endif // MOBJECT_H
