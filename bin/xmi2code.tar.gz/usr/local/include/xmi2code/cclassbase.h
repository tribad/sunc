#ifndef CCLASSBASE_H
#define CCLASSBASE_H

#include <string>
#include <map>
#include <list>
#include <set>
#include <fstream>

#include "mclass.h"
#include "mmodel.h"
#include "cmodel.h"

class CModel;
class MElement;

class CClassBase : public MClass
{
public:
    CClassBase();
    CClassBase(std::string aId, MElement* e) : MClass(aId, e) {};
    static MClass* construct(const std::string&aId, MStereotype* aStereotype=0, MElement *aParent=0);
    static MClass* construct(const std::string&aId, std::string aPackageType, MElement *aParent=0);
    void PrepareBase();
    virtual void SetFromTags(const std::string& name, const std::string&value)=0;
protected:
};

#endif // CCLASSBASE_H
