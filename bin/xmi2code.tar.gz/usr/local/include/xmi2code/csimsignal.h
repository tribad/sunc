#ifndef CSIMSIGNAL_H
#define CSIMSIGNAL_H

class MClass;

class CSimSignal : public MSimSignal
{
public:
    CSimSignal();
    CSimSignal(const std::string& aId, MElement* e) : MSimSignal(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
    MClass *Class;
};

#endif // CSIMSIGNAL_H
