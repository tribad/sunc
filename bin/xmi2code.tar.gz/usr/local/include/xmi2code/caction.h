#ifndef CACTION_H
#define CACTION_H


class CAction : public MAction
{
public:
    CAction();
    CAction(const std::string& aId, MElement* e) : MAction(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CACTION_H
