#ifndef COBJECT_H
#define COBJECT_H

#include "mobject.h"

class CObject : public MObject
{
public:
    CObject();
    CObject(const std::string &aId, MElement *e) : MObject(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // COBJECT_H
