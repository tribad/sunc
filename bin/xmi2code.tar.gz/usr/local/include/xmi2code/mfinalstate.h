#ifndef MFINALSTATE_H
#define MFINALSTATE_H

#include "mstate.h"

class MFinalState : public MState
{
public:
    MFinalState();
    MFinalState(const std::string&aId, MElement *aParent=0) : MState(aId, aParent) {type=eFinalState;};
    static MFinalState* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MFINALSTATE_H
