#ifndef MJSLIFELINE_H
#define MJSLIFELINE_H

#include "melement.h"
#include "mlifeline.h"

class CJSLifeLine;

class MJSLifeLine : public MLifeLine
{
public:
    MJSLifeLine();
    MJSLifeLine(const std::string&aId, MElement *aParent=0);
    static MJSLifeLine* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MJSLifeLine*> Instances;
};

#endif // MJSLIFELINE_H
