#ifndef CPACKAGEBASE_H
#define CPACKAGEBASE_H

#include <string>
#include <fstream>
#include <vector>
#include <list>
#include <map>

#include "melement.h"
#include "mdependency.h"
#include "mpackage.h"

class CModel;

class CPackageBase : public MPackage
{
public:
    CPackageBase();
    CPackageBase(const std::string& aId, MElement* e) : MPackage(aId, e) {};
    virtual ~CPackageBase();
    static MPackage* construct(const std::string&aId, MStereotype* aStereotype=0, MElement *aParent=0);
    static MPackage* construct(const std::string&aId, std::string aPackageType, MElement *aParent=0);

    void OpenStream(std::ofstream&s, const std::string& fname);
    void DumpMakefileHeader(std::ofstream&, std::string fname);
    void DumpMakefileSource(std::ofstream& s, const std::list<std::string>& modules);
    void DumpMakefileObjects(std::ofstream& s, const std::list<std::string>& modules);
    void PrepareBase(const std::map<std::string, std::string>& tags);
    void DumpBase(CModel* model);
    virtual std::list<MDependency*> GetLibraryDependency();
    virtual std::string GetLibraryPath(MElement* s);
    virtual std::string GetLibraryPath(MElement* s, MElement* from);

    std::list<MClass*> GetAllContent(std::list<eElementType> types);
public:
    std::string   Directory;
    std::string   NameSpace;
    std::string   OutputName;
    std::ofstream makefile;
};

#endif // CPACKAGEBASE_H
