#ifndef CSIMOBJECT_H
#define CSIMOBJECT_H

class MElement;
class CAssociationEnd;
class CAttribute;
class MState;
class MTransition;

class CSimObject : public CClassBase
{
public:
    CSimObject();
    CSimObject(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = eSimObject;};
    static MClass* construct(const std::string& aId, MElement* e);
    virtual void SetFromTags(const std::string& name, const std::string&value);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
};

#endif // CSIMOBJECT_H
