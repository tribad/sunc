#ifndef MMESSAGE_H
#define MMESSAGE_H

#include "melement.h"

typedef enum enumMessageType {
    mSyncCall,
    mAsyncCall,
    mAsyncSignal,
    mCreateMessage,
    mDeleteMessage,
    mReply,
    mUnknownMessage
} mMessageType;

class MMessage : public MElement
{
public:
    MMessage();
    MMessage(const std::string&aId, MElement *aParent=0);
    static MMessage* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MMessage*> Instances;
public:
    std::string  source_ref;
    MElement*    source;     // This is a lifeline.
    std::string  target_ref;
    MElement*    target;     //  This is a lifeline.
    mMessageType mtype;
    bool         isConcurrent;
};

#endif // MMESSAGE_H
