#ifndef CSIMENUMERATION_H
#define CSIMENUMERATION_H


class CSimEnumeration : public CClassBase
{
public:
    CSimEnumeration();
    CSimEnumeration(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = eSimEnumeration;};
    virtual void SetFromTags(const std::string& name, const std::string&value);
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
private :
public:
    std::map<std::string, uint64_t> id_map;             //  This map is used to be exported to the ids.
    std::string                     basename;
    std::string                     lower_basename;
    std::string                     upper_basename;
};

#endif // CSIMENUMERATION_H
