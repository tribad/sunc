#ifndef CJSCLASS_H
#define CJSCLASS_H

#include <fstream>
#include <string>

#include "cclassbase.h"

class CJSClass : public CClassBase
{
public:
    CJSClass();
    CJSClass(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = eJSClass;};
    virtual void SetFromTags(const std::string& name, const std::string&value);
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);

    void OpenStream(std::ofstream& s, const std::string& fname);
private:
    std::string   lower_name;
    std::string   upper_name;
    std::string   basename;
    std::ofstream out;
};

#endif // CCLASS_H
