#ifndef MASSOCIATION_H
#define MASSOCIATION_H

#include <vector>

#include "melement.h"

class MAssociationEnd;

class MAssociation : public MElement
{
public:
    MAssociation();
    MAssociation(const std::string&aId, MElement *aParent=0) : MElement(aId, aParent) {type=eAssociation;};
    static MAssociation* construct(const std::string&aId, MElement *aParent=0);
    void AddEnd(MAssociationEnd *e) {ends.push_back(e);};
    MAssociationEnd *ThisEnd(const std::string& ref);
    MAssociationEnd *OtherEnd(const std::string& ref);
public:
    std::vector<MAssociationEnd*> ends;
};

#endif // MASSOCIATION_H
