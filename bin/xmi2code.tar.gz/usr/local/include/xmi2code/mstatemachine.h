#ifndef MSTATEMACHINE_H
#define MSTATEMACHINE_H

#include <vector>
#include "melement.h"

class MState;
class MTransition;

class MStatemachine : public MElement
{
public:
    MStatemachine();
    MStatemachine(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MStatemachine*> Instances;
    std::vector<MState*>      states;
    std::vector<MTransition*> transitions;
};

#endif // MSTATEMACHINE_H
