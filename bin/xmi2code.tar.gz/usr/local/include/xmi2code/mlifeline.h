#ifndef MLIFELINE_H
#define MLIFELINE_H

#include "melement.h"

class MLifeLine : public MElement
{
public:
    MLifeLine();
    MLifeLine(const std::string&aId, MElement *aParent=0);
    static MLifeLine* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MLifeLine*> Instances;
public:
    std::string role_ref;
    MElement*   role;    // This is an attribute.

};

#endif // MLIFELINE_H
