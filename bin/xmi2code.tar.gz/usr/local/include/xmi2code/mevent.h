#ifndef MEVENT_H
#define MEVENT_H

#include "melement.h"

class MEvent : public MElement
{
public:
    MEvent();
    MEvent(const std::string&aId, MElement *aParent=0);
    static MEvent* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MEvent*> Instances;
    std::string                           kind;
};

#endif // MEVENT_H
