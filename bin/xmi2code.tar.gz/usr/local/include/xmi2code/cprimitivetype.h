#ifndef CPRIMITIVETYPE_H
#define CPRIMITIVETYPE_H


class CPrimitiveType : public CClassBase
{
public:
    CPrimitiveType();
    CPrimitiveType(const std::string &aId, MElement *e) : CClassBase(aId, e) {type = ePrimitiveType;};
    //
    //  Virtuals from CClassBase
    virtual void SetFromTags(const std::string& name, const std::string&value);
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CPRIMITIVETYPE_H
