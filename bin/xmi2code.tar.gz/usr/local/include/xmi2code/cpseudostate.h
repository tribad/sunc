#ifndef CPSEUDOSTATE_H
#define CPSEUDOSTATE_H

#include <string>

class CPseudoState : public MPseudoState
{
public:
    CPseudoState();
    CPseudoState(const std::string& aId, MElement* e) : MPseudoState(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CPSEUDOSTATE_H
