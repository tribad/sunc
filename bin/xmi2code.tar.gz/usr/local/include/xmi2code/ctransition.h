#ifndef CTRANSITION_H
#define CTRANSITION_H


class CTransition : public MTransition
{
public:
    CTransition();
    CTransition(const std::string& aId, MElement* e) : MTransition(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CTRANSITION_H
