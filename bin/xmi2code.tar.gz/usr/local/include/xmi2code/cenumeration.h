#ifndef CENUMERATION_H
#define CENUMERATION_H

#include "cclassbase.h"

class CEnumeration : public CClassBase
{
public:
    CEnumeration();
    CEnumeration(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = eEnumeration;};
    virtual void SetFromTags(const std::string& name, const std::string&value);
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CENUMERATION_H
