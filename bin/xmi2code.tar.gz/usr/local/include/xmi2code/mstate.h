#ifndef MSTATE_H
#define MSTATE_H

#include <vector>
#include "melement.h"
#include "mtransition.h"

class MTransition;

class MState : public MElement
{
public:
    MState();
    MState(const std::string&aId, MElement *aParent=0);
    static MState* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MState*> Instances;
    std::vector<MTransition*> Incoming;
    std::vector<MTransition*> Outgoing;
    std::vector<MState*>      States;
    std::vector<MTransition*> Transitions;
    std::vector<MAction*>     DoActions;
    std::vector<MAction*>     EntryActions;
    std::vector<MAction*>     ExitActions;
    MState*                   shallowHistory;
};

#endif // MSTATE_H
