#ifndef MSTEREOTYPE_H
#define MSTEREOTYPE_H

#include <string>

class MStereotype
{
public:
    MStereotype();
    MStereotype(const std::string&aName, const std::string&aId);
public:
    std::string name;
    std::string id;
};

#endif // MSTEREOTYPE_H
