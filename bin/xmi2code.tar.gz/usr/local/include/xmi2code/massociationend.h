#ifndef MASSOCIATIONEND_H
#define MASSOCIATIONEND_H

#include "melement.h"

class MAssociationEnd : public MElement
{
public:
    MAssociationEnd();
    MAssociationEnd(const std::string&aId, MElement *aParent=0);
    static MAssociationEnd* construct(const std::string&aId, MElement *aParent=0);
    void SetClassifier(MElement* a) {ClassifierRef = a->id;}
public:
    static std::map<std::string, MAssociationEnd*> Instances;
    std::string                                    ClassifierRef;
    eAggregation                                   Aggregation;
    std::string                                    Multiplicity;
    bool                                           Navigable;
    std::string                                    defaultValue;
};

#endif // MASSOCIATIONEND_H
