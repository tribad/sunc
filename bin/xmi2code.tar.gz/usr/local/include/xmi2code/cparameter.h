#ifndef CPARAMETER_H
#define CPARAMETER_H

#include "mparameter.h"

class CParameter : public MParameter
{
public:
    CParameter();
    CParameter(const std::string& aId, MElement* e) : MParameter(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CPARAMETER_H
