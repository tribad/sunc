#ifndef MOPERATION_H
#define MOPERATION_H

#include <vector>
#include "melement.h"

class MParameter;

class MOperation : public MElement
{
public:
    MOperation();
    MOperation(const std::string&aId, MElement *aParent=0) : MElement(aId, aParent) {type=eOperation;};
    static MOperation* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MOperation*> Instances;
    std::vector<MParameter*>                  Parameter;
    bool                                      isStatic;
    bool                                      isAbstract;
};

#endif // MOPERATION_H
