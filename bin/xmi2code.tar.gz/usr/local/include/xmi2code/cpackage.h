#ifndef CPACKAGE_H
#define CPACKAGE_H

#include <string>
#include "mpackage.h"

class CPackage : public MPackage
{
public:
    CPackage();
    CPackage(const std::string& aId, MElement* e) : MPackage(aId, e) {};
    virtual ~CPackage();
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
protected:
    std::string Directory;
};

#endif // CPACKAGE_H
