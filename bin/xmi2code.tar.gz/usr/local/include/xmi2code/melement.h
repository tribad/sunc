#ifndef MELEMENT_H
#define MELEMENT_H

#include <vector>
#include <map>
#include <list>
#include <string>

#include "mstereotype.h"

class MModel;
class MElement;

class MReference {
public:
    MReference();
    MReference(const std::string& aId, MElement* aRefPtr=0);
    ~MReference();
    void Set(MElement* aRefPtr=0);
    void Set(const std::string& aRef);
    const std::string& GetRef(void) {return (ref);};
    MElement *GetPtr(void) {return (element);};
    static std::string GetName(const std::string &ref);
    static void Add(const std::string &ref);
public:
    static std::map<std::string, MElement*> Instances;
protected:
    std::string ref;
    MElement*   element;
};

typedef enum tagElementType {
    eElement,
    eClass,
    ePrimitiveType,
    eDataType,
    eAttribute,
    eParameter,
    eOperation,
    eAssociation,
    eAssociationEnd,
    eDependency,
    eGeneralization,
    eLifeLine,
    eWebPageLifeLine,
    eJSLifeLine,
    eUseCase,
    eCxxClass,
    eCollaboration,
    eStruct,
    eUnion,
    eEnumeration,
    eCClass,
    eExternClass,
    eJSClass,
    eStatemachine,
    eState,
    ePseudoState,
    eFinalState,
    eStateTransition,
    eAction,
    eEvent,
    eQtClass,
    eSimMessageClass,
    eSimSignalClass,
    ePHPClass,
    eSimObject,
    eSimEnumeration,
    eSimStatemachine,
    eDocument,
    eSignal,
    eSimSignal,
    eMessage,
    eSimMessage,
    eJSONMessage,
    ePackage,
    eModelPackage,
    eLibraryPackage,
    eJSPackage,
    eExecPackage,
    eExternPackage,
    eSimulationPackage,
    eObject,
    eLink
} eElementType;

typedef enum enumVisibility {
    vNone,
    vPackage,
    vPublic,
    vProtected,
    vPrivate
} eVisibility;

typedef enum enumAggregation {
    aNone,
    aShared,
    aComposition,
    aAggregation
} eAggregation;

class MElement
{
public:
    MElement();
    MElement(const std::string &aId, MElement* aParent=0);
    virtual ~MElement();
    void SetId(const std::string &aId) {id=aId;};
    void SetParent(MElement* aParent) {parent=aParent;};
    void AddTag(const std::string& name, const std::string&value) {tags.insert(std::pair<std::string, std::string>(name, value));};
    virtual std::string FQN(void) = 0;
    virtual void Prepare(void) = 0;
    virtual void Dump(MModel*) = 0;
    void DumpComment(std::ostream& output, int spacer=0, std::string commentintro="/*", std::string commentcontinue=" *", std::string commentend=" */");
    bool HasStereotype(std::string name) {return (stereotypes.find(name)!=stereotypes.end());};
    bool HasTaggedValue(std::string name) {return (tags.find(name)!=tags.end());};
    std::string GetTaggedValue(std::string name) {std::string result;if (tags.find(name)!=tags.end()) result=tags.find(name)->second; return result;};
    bool IsClassBased();
    bool IsPackageBased();
public:
    static std::map<std::string, MElement*> Instances;
    eElementType                            type;
    MElement*                               parent;
    std::string                             id;
    std::string                             name;
    std::string                             comment;
    eVisibility                             visibility;
    std::vector<MElement*>                  Supplier;
    std::vector<MElement*>                  Client;
    std::map<std::string, std::string>      tags;
    std::list<MElement*>                    owned;
    std::map<std::string, MStereotype*>     stereotypes;
};

#endif // MELEMENT_H
