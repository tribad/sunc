#ifndef CQTCLASS_H
#define CQTCLASS_H

#include "cclassbase.h"

class CQtClass : public CClassBase
{
public:
    CQtClass();
    CQtClass(const std::string&aId, MElement* e) : CClassBase(aId, e) {type = eQtClass;};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CQTCLASS_H
