#ifndef MPSEUDOSTATE_H
#define MPSEUDOSTATE_H

#include "mstate.h"

class MPseudoState : public MState
{
public:
    MPseudoState();
    MPseudoState(const std::string&aId, MElement *aParent=0) : MState(aId, aParent) {type=ePseudoState;};
    static MPseudoState* construct(const std::string&aId, MElement *aParent=0);
public:
    std::string kind;
};

#endif // MPSEUDOSTATE_H
