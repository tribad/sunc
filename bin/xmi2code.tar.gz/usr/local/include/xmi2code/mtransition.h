#ifndef MTRANSITION_H
#define MTRANSITION_H

#include <vector>
#include <string>

#include "melement.h"

class MState;
class MEvent;
class MAction;

class MTransition : public MElement
{
public:
    MTransition();
    MTransition(const std::string&aId, MElement *aParent=0) : MElement(aId, aParent) {type=eStateTransition;};
    static MTransition* construct(const std::string&aId, MElement *aParent=0);
public:
    std::string           kind;
    std::string           from_ref;
    MState*               from;
    std::string           to_ref;
    MState*               to;
    std::string           guard;
    std::vector<MEvent*>  events;
    std::vector<MAction*> actions;
};

#endif // MTRANSITION_H
