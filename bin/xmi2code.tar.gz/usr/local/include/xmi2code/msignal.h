#ifndef MSIGNAL_H
#define MSIGNAL_H

#include "mclass.h"

class MSignal : public MClass
{
public:
    MSignal();
    MSignal(const std::string&aId, MElement *aParent=0) : MClass(aId, aParent) {type=eSignal;};
    static MSignal* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MSIGNAL_H
