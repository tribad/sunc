#ifndef CSIMSTATEMACHINE_H
#define CSIMSTATEMACHINE_H

class CPseudoState;

class CSimStatemachine : public MSimStatemachine
{
public:
    CSimStatemachine();
    CSimStatemachine(const std::string& aId, MElement* e) : MSimStatemachine(aId, e) {history=0;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
    //
    //
public:
    CPseudoState* history;
};

#endif // CSIMSTATEMACHINE_H
