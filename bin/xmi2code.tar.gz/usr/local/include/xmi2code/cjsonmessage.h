#ifndef CJSONMESSAGE_H
#define CJSONMESSAGE_H

#include "mclass.h"

class CAttribute;
class CAssociationEnd;

class CJSONMessage : public MJSONMessage
{
public:
    CJSONMessage();
    CJSONMessage(const std::string& aId, MElement* e) : MJSONMessage(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
    MClass* Class;
};

#endif // CJSONMESSAGE_H
