#ifndef CCOLLABORATION_H
#define CCOLLABORATION_H


class CCollaboration : public CClassBase
{
public:
    CCollaboration();
    CCollaboration(const std::string& aId, MElement* e) : CClassBase(aId, e) {type=eCollaboration;};
    void SetFromTags(const std::string& name, const std::string&value);
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CCOLLABORATION_H
