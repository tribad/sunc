#ifndef MDATATYPE_H
#define MDATATYPE_H

#include "mclass.h"


class MDataType : public MClass
{
public:
    MDataType();
    MDataType(const std::string&aId, MElement *aParent=0);
    static MDataType* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MDataType*> Instances;

};

#endif // MDATATYPE_H
