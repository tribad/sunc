#ifndef CATTRIBUTE_H
#define CATTRIBUTE_H


class CAttribute : public MAttribute
{
public:
    CAttribute();
    CAttribute(const std::string &aId, MElement *e) : MAttribute(aId, e) {Classifier=0;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
    std::string Qualifier;
    std::string QualifierName;
    std::string QualifierType;

};

#endif // CATTRIBUTE_H
