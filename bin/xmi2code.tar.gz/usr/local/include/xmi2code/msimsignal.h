#ifndef MSIMSIGNAL_H
#define MSIMSIGNAL_H

#include "mmessage.h"

class MSimSignal : public MMessage
{
public:
    MSimSignal();
    MSimSignal(const std::string&aId, MElement *aParent=0) : MMessage(aId, aParent) {type=eSimSignal;};
    static MSimSignal* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MSIMSIGNAL_H
