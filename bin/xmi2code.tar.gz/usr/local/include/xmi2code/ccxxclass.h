#ifndef CCXXCLASS_H
#define CCXXCLASS_H

class CCxxClass : public CClassBase
{
public:
    CCxxClass();
    CCxxClass(const std::string&aId, MElement *e) : CClassBase(aId, e) {type = eCxxClass;};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);

};

#endif // CCXXCLASS_H
