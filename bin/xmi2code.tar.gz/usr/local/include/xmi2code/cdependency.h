#ifndef CDEPENDENCY_H
#define CDEPENDENCY_H

#include "mdependency.h"

class CDependency : public MDependency
{
public:
    CDependency();
    CDependency(const std::string &aId, MElement *e) : MDependency(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CDEPENDENCY_H
