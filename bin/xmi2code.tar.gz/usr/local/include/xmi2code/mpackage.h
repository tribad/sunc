#ifndef MPACKAGE_H
#define MPACKAGE_H

#include <vector>
#include "melement.h"
#include "mclass.h"
#include "mdependency.h"
#include "mstereotype.h"
#include "mobject.h"

class MPackage : public MElement
{
public:
    MPackage();
    MPackage(const std::string&aId, MElement *aParent=0) : MElement(aId, aParent) {type=ePackage;
                                                                                   MPackage::Instances.insert(std::pair<std::string, MPackage*>(aId, this));
                                                                                  };
    static MPackage* construct(const std::string&aId, MStereotype* aStereotype=0, MElement *aParent=0);
    static MPackage* construct(const std::string&aId, std::string aPackageType, MElement *aParent=0);
    void Add(MClass*c) {Classes.push_back(c);owned.push_back(c);};
    void Add(MObject*o) {Objects.push_back(o);owned.push_back(o);};
    void Add(MPackage* p) {Packages.push_back(p); owned.push_back(p);};
    std::string GetDefaultStereotype();
public:
    static std::map<std::string, MPackage*> Instances;
    std::vector<MClass*>      Classes;
    std::vector<MPackage*>    Packages;
    std::vector<MDependency*> Dependency;
    std::vector<MObject*>     Objects;
};

#endif // MPACKAGE_H
