#ifndef CEXECUTABLEPACKAGE_H
#define CEXECUTABLEPACKAGE_H

#include "melement.h"


class CExecutablePackage : public CPackageBase
{
public:
    CExecutablePackage();
    CExecutablePackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {type = eExecPackage;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
    std::ofstream makefile;
};

#endif // CEXECUTABLEPACKAGE_H
