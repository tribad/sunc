#ifndef CDOCUMENT_H
#define CDOCUMENT_H


class CDocument : public MDocument
{
public:
    CDocument();
    CDocument(const std::string& aId, MElement* e) : MDocument(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CDOCUMENT_H
