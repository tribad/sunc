#ifndef CLIFELINE_H
#define CLIFELINE_H


class CLifeLine : public MLifeLine
{
public:
    CLifeLine();
    CLifeLine(const std::string& aId, MElement* e) : MLifeLine(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
    //
    //  Others.
    void SetIncoming(MElement* e);
    void SetOutgoing(MElement* e);
};

#endif // CLIFELINE_H
