#ifndef CLINK_H
#define CLINK_H

#include <string>
#include "melement.h"
#include "mlink.h"

class CLink : public MLink
{
public:
    CLink();
    CLink(const std::string &aId, MElement *e) : MLink(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CLINK_H
