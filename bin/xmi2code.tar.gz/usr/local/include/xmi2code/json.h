#ifndef JSON_H
#define JSON_H

#include <string>
#include <utility>
#include <map>
#include <vector>
#include <istream>

enum class eJSON {
    eDouble=0x0001,
    eInteger,
    eBoolean,
    eNull,
    eString,
    eObject,
    eArray,
};


typedef struct tagJSON {
    struct tagJSON *parent;
    std::string    name;
    int            state;
    eJSON          type;
} tJSON;

typedef struct tagJSONDouble {
    struct tagJSON *parent;
    std::string    name;
    int            state;
    eJSON          type;
    double         value;
} tJSONDouble;

typedef struct tagJSONInteger {
    struct tagJSON *parent;
    std::string    name;
    int            state;
    eJSON          type;
    long           value;
} tJSONInteger;

typedef struct tagJSONBoolean {
    struct tagJSON *parent;
    std::string    name;
    int            state;
    eJSON          type;
    bool           value;
} tJSONBoolean;

typedef struct tagJSONNull {
    struct tagJSON *parent;
    std::string    name;
    int            state;
    eJSON          type;
} tJSONNull;

typedef struct tagJSONString {
    struct tagJSON *parent;
    std::string    name;
    int            state;
    eJSON          type;
    std::string    value;
} tJSONString;

typedef struct tagJSONObject {
    struct tagJSON*                 parent;
    std::string                     name;
    int                             state;
    eJSON                           type;
    std::map< std::string, tJSON*>  value;
} tJSONObject;

typedef struct tagJSONArray {
    struct tagJSON*     parent;
    std::string         name;
    int                 state;
    eJSON               type;
    std::vector<tJSON*> value;
} tJSONArray;

tJSON *jsonparser(std::istream&);
std::ostream& jsondump(tJSON* root, std::ostream& out) ;

#endif // JSON_H

