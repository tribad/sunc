#ifndef CEXTERNPACKAGE_H
#define CEXTERNPACKAGE_H

#include <list>

class MDependency;

class CExternPackage : public CPackageBase
{
public:
    CExternPackage();
    CExternPackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {type = eExternPackage;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
    std::list<MDependency*> GetLibraryDependency();
};

#endif // CEXTERNPACKAGE_H
