#ifndef CMESSAGE_H
#define CMESSAGE_H


class CMessage : public MMessage
{
public:
    CMessage();
    CMessage(const std::string& aId, MElement* e) : MMessage(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CMESSAGE_H
