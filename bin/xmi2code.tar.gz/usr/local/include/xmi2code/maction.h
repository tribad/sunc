#ifndef MACTION_H
#define MACTION_H

#include "melement.h"

class MAction : public MElement
{
public:
    MAction();
    MAction(const std::string&aId, MElement *aParent=0);
    static MAction* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MAction*> Instances;
};

#endif // MACTION_H
