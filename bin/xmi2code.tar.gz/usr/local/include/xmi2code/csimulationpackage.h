#ifndef CSIMULATIONPACKAGE_H
#define CSIMULATIONPACKAGE_H

#include <string>
#include <list>

class MDependency;

class CSimulationPackage : public CPackageBase
{
public:
    CSimulationPackage();
    CSimulationPackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {type = eSimulationPackage;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
private:
    std::ofstream delreq;
    std::ofstream delreply;
    std::ofstream delindication;
    std::ofstream delconfirm;
    std::ofstream ids_h;
    std::ofstream ids_sql;
    std::ofstream ids_php;
    std::ofstream ifc;
};

#endif // CSIMULATIONPACKAGE_H
