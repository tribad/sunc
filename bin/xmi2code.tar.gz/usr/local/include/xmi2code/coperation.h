#ifndef COPERATION_H
#define COPERATION_H

#include <string>
#include "melement.h"

class COperation : public MOperation
{
public:
    COperation();
    COperation(const std::string& aId, MElement* e) : MOperation(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
    std::string GetReturnType(void);
    std::string GetReturnName(void);
    std::string GetReturnDefault(void);
    std::string GetParameterDecl(void);
    std::string GetParameterDefinition(void);
    std::string GetPHPParameterDefinition(void);
};

#endif // COPERATION_H
