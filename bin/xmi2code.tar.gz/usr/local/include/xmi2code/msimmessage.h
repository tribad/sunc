#ifndef MSIMMESSAGE_H
#define MSIMMESSAGE_H

#include "mmessage.h"

class MSimMessage : public MMessage
{
public:
    MSimMessage();
    MSimMessage(const std::string&aId, MElement *aParent=0) : MMessage(aId, aParent) {type=eSimMessage;};
    static MSimMessage* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MSIMMESSAGE_H
