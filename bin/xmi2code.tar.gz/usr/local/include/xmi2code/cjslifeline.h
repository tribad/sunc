#ifndef CJSLIFELINE_H
#define CJSLIFELINE_H


class CJSLifeLine : public MJSLifeLine
{
public:
    CJSLifeLine();
    CJSLifeLine(const std::string& aId, MElement* e) : MJSLifeLine(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
    //
    //  Others.
    void SetIncoming(MElement* e);
    void SetOutgoing(MElement* e);
};

#endif // CJSLIFELINE_H
