#ifndef MWEBPAGELIFELINE_H
#define MWEBPAGELIFELINE_H

#include "melement.h"
#include "mlifeline.h"

class CWebPageLifeLine;

class MWebPageLifeLine : public MLifeLine
{
public:
    MWebPageLifeLine();
    MWebPageLifeLine(const std::string&aId, MElement *aParent=0);
    static MWebPageLifeLine* construct(const std::string&aId, MElement *aParent=0);
public:

};

#endif // MLIFELINE_H
