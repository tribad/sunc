#ifndef MSIMSTATEMACHINE_H
#define MSIMSTATEMACHINE_H

#include "mstatemachine.h"

class MSimStatemachine : public MStatemachine
{
public:
    MSimStatemachine();
    MSimStatemachine(const std::string&aId, MElement *aParent=0) : MStatemachine(aId, aParent) {type=eSimStatemachine;};
    static MSimStatemachine* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MSIMSTATEMACHINE_H
