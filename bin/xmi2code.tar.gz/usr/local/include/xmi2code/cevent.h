#ifndef CEVENT_H
#define CEVENT_H


class CEvent : public MEvent
{
public:
    CEvent();
    CEvent(const std::string& aId, MElement* e) : MEvent(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CEVENT_H
