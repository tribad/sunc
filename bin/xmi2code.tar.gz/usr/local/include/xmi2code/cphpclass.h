#ifndef CPHPCLASS_H
#define CPHPCLASS_H

#include "cclassbase.h"
#include "moperation.h"
#include "coperation.h"

class CPHPClass : public CClassBase
{
public:
    CPHPClass();
    CPHPClass(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = ePHPClass;};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CPHPCLASS_H
