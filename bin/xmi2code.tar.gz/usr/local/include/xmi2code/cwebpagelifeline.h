#ifndef CWEBPAGELIFELINE_H
#define CWEBPAGELIFELINE_H


class CWebPageLifeLine : public MWebPageLifeLine
{
public:
    CWebPageLifeLine();
    CWebPageLifeLine(const std::string& aId, MElement* e) : MWebPageLifeLine(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
    //
    //  Others.
    void SetIncoming(MElement* e);
    void SetOutgoing(MElement* e);
};

#endif // CLIFELINE_H
