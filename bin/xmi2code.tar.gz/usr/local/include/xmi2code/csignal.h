#ifndef CSIGNAL_H
#define CSIGNAL_H


class CSignal : public MSignal
{
public:
    CSignal();
    CSignal(const std::string& aId, MElement* e) : MSignal(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CSIGNAL_H
