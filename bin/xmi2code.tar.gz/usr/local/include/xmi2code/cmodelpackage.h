#ifndef CMODELPACKAGE_H
#define CMODELPACKAGE_H

#include "cpackagebase.h"

class CModelPackage : public CPackageBase
{
public:
    CModelPackage();
    CModelPackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {type = eModelPackage;};
    virtual ~CModelPackage();
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
private:
    std::ofstream makefile;
};

#endif // CMODELPACKAGE_H
