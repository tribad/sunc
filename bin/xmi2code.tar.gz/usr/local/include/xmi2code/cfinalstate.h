#ifndef CFINALSTATE_H
#define CFINALSTATE_H


class CFinalState : public MFinalState
{
public:
    CFinalState();
    CFinalState(const std::string& aId, MElement* e) : MFinalState(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CFINALSTATE_H
