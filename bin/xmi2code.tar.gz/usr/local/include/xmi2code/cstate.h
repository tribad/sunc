#ifndef CSTATE_H
#define CSTATE_H


class CState : public MState
{
public:
    CState();
    CState(const std::string& aId, MElement* e) : MState(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);

    std::list<std::string> GetHistoryAttributes(std::string prefix) ;
public:
};


#endif // CSTATE_H
