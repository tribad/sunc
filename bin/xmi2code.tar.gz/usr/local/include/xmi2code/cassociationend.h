#ifndef CASSOCIATIONEND_H
#define CASSOCIATIONEND_H


class CAssociationEnd : public MAssociationEnd
{
public:
    CAssociationEnd();
    CAssociationEnd(const std::string &aId, MElement *e) : MAssociationEnd(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
    MElement*   Classifier;
    std::string Qualifier;
    std::string QualifierName;
    std::string QualifierType;
};

#endif // CASSOCIATIONEND_H
