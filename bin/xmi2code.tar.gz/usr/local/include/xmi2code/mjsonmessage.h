#ifndef MJSONMESSAGE_H
#define MJSONMESSAGE_H

#include "mmessage.h"

class MJSONMessage : public MMessage
{
public:
    MJSONMessage();
    MJSONMessage(const std::string&aId, MElement *aParent=0) : MMessage(aId, aParent) {type=eJSONMessage;};
    static MJSONMessage* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MJSONMESSAGE_H
