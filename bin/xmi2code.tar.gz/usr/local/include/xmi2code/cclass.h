#ifndef CCLASS_H
#define CCLASS_H

#include "cclassbase.h"

class CClass : public CClassBase
{
public:
    CClass();
    CClass(const std::string &aId, MElement *e) : CClassBase(aId, e) {type = eClass;};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CCLASS_H
