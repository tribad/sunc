#ifndef MATTRIBUTE_H
#define MATTRIBUTE_H

#include "melement.h"

class MAttribute : public MElement
{
public:
    MAttribute();
    MAttribute(const std::string&aId, MElement *aParent=0);
    ~MAttribute();
    static MAttribute* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MAttribute*> Instances;
public:
    std::string  ClassifierRef;
    std::string  ClassifierName;
    MElement*    Classifier;
    bool         isStatic;
    bool         isReadOnly;
    eAggregation Aggregation;
    std::string  Multiplicity;
    std::string  defaultValue;
};

#endif // MATTRIBUTE_H
