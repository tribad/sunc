#ifndef CUSECASE_H
#define CUSECASE_H


class CUseCase : public MUseCase
{
public:
    CUseCase();
    CUseCase(const std::string& aId, MElement* e) : MUseCase(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CUSECASE_H
