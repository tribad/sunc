#ifndef __STARUML_PARSER_INC
#define __STARUML_PARSER_INC

class MModel;

extern "C" {
MModel* staruml_modelparser(const char* filename, const char* directory);
}

#endif
