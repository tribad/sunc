#ifndef CUNION_H
#define CUNION_H

#include "cclassbase.h"

class CUnion : public CClassBase
{
public:
    CUnion();
    CUnion(const std::string& aId, MElement* e) : CClassBase(aId, e) {type = eUnion;};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CUNION_H
