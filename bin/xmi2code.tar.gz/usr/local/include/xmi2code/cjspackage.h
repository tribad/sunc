#ifndef CJSPACKAGE_H
#define CJSPACKAGE_H


class CJSPackage : public CPackageBase
{
public:
    CJSPackage();
    CJSPackage(const std::string& aId, MElement* e) : CPackageBase(aId, e) {type = eJSPackage;};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CLIBRARYPACKAGE_H
