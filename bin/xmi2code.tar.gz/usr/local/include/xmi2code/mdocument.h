#ifndef MDOCUMENT_H
#define MDOCUMENT_H

#include "mclass.h"

class MDocument : public MClass
{
public:
    MDocument();
    MDocument(const std::string&aId, MElement *aParent=0) : MClass(aId, aParent) {type=eDocument;};
    static MDocument* construct(const std::string&aId, MElement *aParent=0);
};

#endif // MDOCUMENT_H
