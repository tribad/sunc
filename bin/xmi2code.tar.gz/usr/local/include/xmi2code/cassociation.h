#ifndef CASSOCIATION_H
#define CASSOCIATION_H


class CAssociation : public MAssociation
{
public:
    CAssociation();
    CAssociation(const std::string &aId, MElement *e) : MAssociation(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CASSOCIATION_H
