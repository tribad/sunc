#ifndef CSIMMESSAGE_H
#define CSIMMESSAGE_H


class CSimMessage : public MSimMessage
{
public:
    CSimMessage();
    CSimMessage(const std::string& aId, MElement* e) : MSimMessage(aId, e) {};
    //
    //  Virtuals from MElement
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
public:
    MClass* Class;
};

#endif // CSIMMESSAGE_H
