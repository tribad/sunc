#ifndef CDATATYPE_H
#define CDATATYPE_H

#include "cclassbase.h"

class CDataType : public CClassBase
{
public:
    CDataType();
    CDataType(const std::string& aId, MElement* e) : CClassBase(aId, e) {};
    static MClass* construct(const std::string& aId, MElement* e);
    //
    //  Virtuals from MElement
    virtual void SetFromTags(const std::string& name, const std::string&value);
    virtual std::string FQN(void);
    virtual void Prepare(void);
    virtual void Dump(MModel*);
};

#endif // CEVENT_H
