#ifndef MGENERALIZATION_H
#define MGENERALIZATION_H

#include "melement.h"

class MGeneralization : public MElement
{
public:
    MGeneralization();
    MGeneralization(const std::string&aId, MElement *aParent=0) : MElement(aId, aParent) {type=eGeneralization;};
    static MGeneralization* construct(const std::string&aId, MStereotype* aStereotype, MElement *aParent=0);
public:
    static std::map<std::string, MGeneralization*> Instances;
    std::string base_ref;
    MElement* base;
    std::string derived_ref;
    MElement* derived;
};

#endif // MGENERALIZATION_H
