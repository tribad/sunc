#ifndef MCLASS_H
#define MCLASS_H

#include <vector>

#include "melement.h"
#include "mmessage.h"

class MAssociation;
class MAssociationEnd;
class MAttribute;
class MStatemachine;
class MOperation;
class MDependency;
class MGeneralization;

class MClass : public MElement
{
public:
    MClass();
    MClass(const std::string&aId, MElement *aParent=0);
    static MClass* construct(const std::string&aId, MStereotype* aStereotype=0, MElement *aParent=0);
    static MClass* construct(const std::string&aId, std::string aPackageType, MElement *aParent=0);
    void Add(MAssociation* a);
    void Add(MAttribute* a);
    void SetName(std::string name);
public:
    static std::map<std::string, MClass*> Instances;
    static std::map<std::string, MClass*> ByName;
public:
    std::vector<MAttribute*>      Attribute;
    std::vector<MOperation*>      Operation;
    std::vector<MAssociation*>    Association;
    std::vector<MAssociationEnd*> OwnEnd;
    std::vector<MAssociationEnd*> OtherEnd;
    std::vector<MMessage*>        Incoming;
    std::vector<MMessage*>        Outgoing;
    std::vector<MDependency*>     Dependency;
    std::vector<MGeneralization*> Generalization;
    MStatemachine*                statemachine;
};

#endif // MCLASS_H
