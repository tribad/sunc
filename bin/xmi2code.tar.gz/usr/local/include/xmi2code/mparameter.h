#ifndef MPARAMETER_H
#define MPARAMETER_H

class MElement;

class MParameter : public MElement
{
public:
    MParameter();
    MParameter(const std::string&aId, MElement *aParent=0);
    static MParameter* construct(const std::string&aId, MElement *aParent=0);
public:
    static std::map<std::string, MParameter*> Instances;
    std::string                               defaultValue;
    std::string                               Multiplicity;
    std::string                               Direction;
    bool                                      isReadOnly;
    std::string                               ClassifierName;
    std::string                               ClassifierRef;
    MElement*                                 Classifier;
};

#endif // MPARAMETER_H
